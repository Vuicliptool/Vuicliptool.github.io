/**
 * js/lesson-player.js
 * Quản lý tiến độ học (localStorage), mở khóa bài đã học và điều khiển phát bài học
 */
window.AppTV = window.AppTV || {};

(function (ns) {
  const STORAGE_KEY = 'APPTV_PROGRESS_V1';

  // ===== MODULE LƯU TIẾN ĐỘ HỌC CỦA BÉ (localStorage) =====
  function loadProgressMap() {
    try {
      const raw = window.localStorage ? window.localStorage.getItem(STORAGE_KEY) : null;
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch (e) {}
    return {};
  }

  function saveProgressMap(map) {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
      }
    } catch (e) {}
  }

  function getLessonKey(lesson, catName) {
    if (!lesson) return '';
    const c = (catName || lesson._catName || '').trim();
    const n = (lesson.name || '').trim();
    return c ? `${c}::${n}` : n;
  }

  const Progress = {
    isCompleted(mod, lesson, catName) {
      if (!mod || !lesson) return false;
      const map = loadProgressMap();
      const list = Array.isArray(map[mod]) ? map[mod] : [];
      const key = getLessonKey(lesson, catName);
      return list.includes(key);
    },

    markCompleted(mod, lesson, catName) {
      if (!mod || !lesson) return;
      const map = loadProgressMap();
      if (!Array.isArray(map[mod])) map[mod] = [];
      const key = getLessonKey(lesson, catName);
      if (key && !map[mod].includes(key)) {
        map[mod].push(key);
        saveProgressMap(map);
      }
    },

    getNextUncompletedLesson(mod, categories) {
      if (!Array.isArray(categories) || categories.length === 0) return null;
      let firstLesson = null;

      for (const cat of categories) {
        const lessons = cat.lessons || [];
        for (const lesson of lessons) {
          lesson._catName = cat.name;
          lesson._module = mod;
          if (!firstLesson) firstLesson = lesson;
          if (!this.isCompleted(mod, lesson, cat.name)) {
            return lesson; // Trả về bài học mới đầu tiên bé chưa hoàn thành
          }
        }
      }
      // Nếu bé đã học xong hết tất cả bài trong môn này -> quay về bài đầu tiên để ôn tập
      return firstLesson;
    },

    resetModule(mod) {
      const map = loadProgressMap();
      if (mod) {
        delete map[mod];
      } else {
        Object.keys(map).forEach(k => delete map[k]);
      }
      saveProgressMap(map);
    }
  };

  ns.Progress = Progress;

  // ===== TRÌNH PHÁT BÀI HỌC (LESSON PLAYER) =====
  let currentLesson = null;
  let currentModule = 'data';
  let currentSteps = [];
  let currentStepIdx = 0;
  let stepRunToken = 0;

  function extractStepsFromLesson(lesson) {
    const steps = [];
    if (Array.isArray(lesson.intro)) {
      lesson.intro.forEach(item => {
        if (item.animation) steps.push(item.animation);
        if (Array.isArray(item.animations)) {
          item.animations.forEach(a => steps.push(a));
        }
      });
    }
    if (lesson.write1) {
      steps.push({ name: 'write_svg', svg: lesson.write1, label: lesson.name });
    }
    if (Array.isArray(lesson.write1s)) {
      lesson.write1s.forEach(svgPath => {
        steps.push({ name: 'write_svg', svg: svgPath, label: lesson.name });
      });
    }
    return steps;
  }

  function openLesson(lesson, modName, catName) {
    ns.Media.playEffect('button');
    // Khi vào bài học -> Không có nhạc nền
    ns.Media.stopBgm();

    if (catName) lesson._catName = catName;
    if (modName) lesson._module = modName;

    currentLesson = lesson;
    currentModule = lesson._module || modName || 'data';
    currentSteps = extractStepsFromLesson(lesson);
    currentStepIdx = 0;

    document.getElementById('stageTitle').textContent = lesson.name;
    document.getElementById('stageOverlay').classList.add('open');
    renderCurrentStep();
  }

  function markCurrentLessonDone() {
    if (currentLesson && currentModule) {
      Progress.markCompleted(currentModule, currentLesson, currentLesson._catName);
    }
  }

  function closeStage() {
    stepRunToken++;
    ns.Media.stopActiveAudio();
    document.getElementById('stageOverlay').classList.remove('open');

    // Cập nhật lại danh sách bài học để mất ổ khóa ở bài vừa hoàn thành
    if (ns.MainApp && typeof ns.MainApp.renderAllSections === 'function') {
      ns.MainApp.renderAllSections();
    }
    // Quay về danh sách lesson -> Phát lại nhạc nền bg_lesson.mp3
    ns.Media.playBgm('bg_lesson');
  }

  function prevStep() {
    if (currentStepIdx > 0) {
      currentStepIdx--;
      renderCurrentStep();
    }
  }

  function nextStep() {
    if (currentStepIdx < currentSteps.length - 1) {
      currentStepIdx++;
      renderCurrentStep();
    } else {
      // Đã đến bước cuối -> Lưu hoàn thành bài học, phát nhạc chúc mừng và quay về danh sách
      markCurrentLessonDone();
      ns.Media.playEffect('lesson_complete');

      const nextBtn = document.getElementById('nextStepBtn');
      if (nextBtn) {
        nextBtn.disabled = true;
        nextBtn.textContent = '🌟 Đã xong!';
      }

      const finishToken = ++stepRunToken;
      setTimeout(() => {
        if (nextBtn) nextBtn.disabled = false;
        if (finishToken === stepRunToken) {
          closeStage();
        }
      }, 1200);
    }
  }

  function renderCurrentStep() {
    stepRunToken++;
    const myToken = stepRunToken;
    ns.Media.stopActiveAudio();

    const body = document.getElementById('stageBody');
    body.innerHTML = '';

    const totalSteps = Math.max(1, currentSteps.length);
    const isLastStep = currentStepIdx >= currentSteps.length - 1;

    document.getElementById('stepIndicator').textContent = `${currentStepIdx + 1} / ${totalSteps}`;
    document.getElementById('prevStepBtn').disabled = currentStepIdx === 0;

    const nextBtn = document.getElementById('nextStepBtn');
    if (nextBtn) {
      nextBtn.disabled = false;
      if (isLastStep) {
        nextBtn.textContent = '🎉 Hoàn thành';
        nextBtn.style.background = 'linear-gradient(180deg, #22c55e, #15803d)';
      } else {
        nextBtn.textContent = 'Tiếp ➡';
        nextBtn.style.background = '';
      }
    }

    const step = currentSteps[currentStepIdx];
    if (!step) {
      body.innerHTML = '<div class="board-card"><p>Bài học đang trống.</p></div>';
      return;
    }

    if (step.name === 'complex') {
      renderComplexAnimation(step, body, myToken, isLastStep);
    } else if (step.name === 'write_svg') {
      ns.WritingBoard.renderWritingCanvas(step.svg, step.label, body);
    } else if (step.name === 'game') {
      ns.GamesEngine.renderGameStep(step, currentLesson, body);
    }
  }

  async function renderComplexAnimation(step, container, token, isLastStep) {
    const card = document.createElement('div');
    card.className = 'board-card';
    card.style.minHeight = '420px';
    card.style.justifyContent = 'space-between';

    const visualBox = document.createElement('div');
    visualBox.className = 'svg-stage';
    visualBox.style.width = '100%';
    visualBox.style.height = '340px';
    visualBox.style.maxWidth = '380px';

    if (currentLesson.thumb) {
      visualBox.appendChild(ns.Media.createSmartSvgElement(currentLesson.thumb, currentLesson.name));
    }

    const bigText = document.createElement('div');
    bigText.className = 'big-letter';
    bigText.style.display = 'none';

    const subBox = document.createElement('div');
    subBox.className = 'subtitle-box';
    subBox.style.display = 'none';

    card.appendChild(visualBox);
    card.appendChild(bigText);
    card.appendChild(subBox);
    container.appendChild(card);

    const rawText = step.text || '';
    const segments = rawText.split('#');
    const soundQueue = [];

    segments.forEach(seg => {
      let s = seg.trim();
      if (!s) return;
      const safeRegex = /\[(svg|write|animation):([^\]]+)\]/g;
      let match;
      while ((match = safeRegex.exec(s)) !== null) {
        soundQueue.push({ tagType: match[1], tagVal: match[2] });
      }
      const cleanAudio = s.replace(safeRegex, '').trim();
      if (cleanAudio) {
        soundQueue.push({ audio: cleanAudio });
      }
    });

    for (const item of soundQueue) {
      if (token !== stepRunToken) return;
      if (item.tagType === 'svg' || item.tagType === 'write') {
        visualBox.innerHTML = '';
        visualBox.appendChild(ns.Media.createSmartSvgElement(item.tagVal, currentLesson.name));
      } else if (item.tagType === 'animation') {
        const parts = item.tagVal.split(':');
        const xamlName = parts[0].replace(/^\/+/, '');
        const sbName = parts[1] || 'sb1';
        visualBox.innerHTML = '';
        await ns.XamlParser.renderXamlToContainer(xamlName, sbName, visualBox);
      } else if (item.audio) {
        await ns.Media.playSoundToken(item.audio);
      }
    }

    // Nếu đã chạy xong toàn bộ nội dung của bước cuối -> tự động ghi nhận đã học xong
    if (token === stepRunToken && isLastStep) {
      markCurrentLessonDone();
    }
  }

  ns.LessonPlayer = {
    openLesson,
    closeStage,
    prevStep,
    nextStep,
    replayStep: renderCurrentStep,
    markCurrentLessonDone
  };
})(window.AppTV);
